﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication84
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    namespace Tipos_de_Busquedas
    {
        class Program
        {
            static void Main(string[] args)
            {
                Listas1 n = new Listas1();
                n.Inicializar();
            }
        }
    }
}