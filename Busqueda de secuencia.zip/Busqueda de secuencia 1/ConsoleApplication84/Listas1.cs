﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication84
{
    class Listas1
    {
        public void Inicializar()
        {
            TipoBusqueda TB = new TipoBusqueda();

                List<int> Lista = new List<int>();//creamos la lista
            //se agregan los numeros a la lista creada 
                Lista.Add(78);
                Lista.Add(35);
                Lista.Add(243);
                Lista.Add(2);
                Lista.Add(65);
                Lista.Add(4);
                Lista.Add(243);
                Lista.Add(12);
                Lista.Add(1);
                foreach (var item in Lista)//se guarda los numeros en una variable
                {
                    Console.WriteLine(item);//se imprime la lista
                }
                
                int Elemnto = 20;

                Console.WriteLine("BUSQUEDA SECUENCIAL");
                Console.WriteLine();
                Console.WriteLine("El elemento " + Elemnto);//se imprime el numero si esta en la lista o no 
                Console.WriteLine("¿se encuentra en la lista? " + TB.BusquedaSecuencial(Elemnto, Lista)); 
                Console.ReadKey();
            }
        }

        class TipoBusqueda
        {
            public bool BusquedaSecuencial(int Elemento, List<int> Lista)
            {
                int Tamaño = Lista.Count; //cuenta los numeros de la lista
                int Posicion = 0;//la posicion

                while (Posicion < Tamaño)//checa el tamaño de la lista
                {
                    if (Lista[Posicion] == Elemento)//compara si el numero se encuentra en la lista
                    {
                        return true;
                    }
                    else //si no esta en la lista
                    {
                        Posicion++;
                    }
                }
                return false; //se regresa si es falso
            }
        }

        }

  
