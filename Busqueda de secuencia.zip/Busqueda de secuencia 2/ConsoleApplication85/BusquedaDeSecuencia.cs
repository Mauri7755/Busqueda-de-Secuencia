﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication85
{
    class BusquedaDeSecuencia
    {
        public void Inicializar()
        {
            int numero, i=0, pos=0;//declaracion de variables
            int [] vec = {3,65,8,1,2,88,9,0,6,2};//se crea lista
            bool encontro=false;
            Console.WriteLine("por favor de ingresar un numero:");//mensaje del numero que desa ingresar
                numero= int.Parse(Console.ReadLine());//ingresar el numero
            while (!(encontro)&& i<10)//compracion del numero en la lista
            {
                if (numero== vec[i])//compra el numero si se encontra
                {
                    encontro=true;//si no lo esta
                    pos=i;
                }
            }

            if (encontro)
                Console.WriteLine("el dato se encuentra en la posicion:" + pos + 1);//se imprime 
        }
        
    }
}

        